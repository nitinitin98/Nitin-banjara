package asd;

import java.util.Arrays;
import java.util.Scanner;

public class Demo {
	public static void main(String[] args)throws java.lang.Exception {
		 Scanner s = new Scanner(System.in);
	        String i = s.nextLine();
	        i=i.replaceAll("\\s", "");
	       	String[] s1 = i.split(",");
	        int[] in= new int[s1.length];
	        int z=0;
	        int sum1 =0;
	        int sum2=0;
	        for(String x: s1){
	            in[z]=Integer.valueOf(x);
	        	sum1+=in[z];
	            z++;
	        }
	        for(int x=0;x<in.length;x++){
	            sum1-=in[x];
	            if(sum1==sum2)
	                System.out.println(x);
	            sum2+=in[x];  
	        }
	}	
	}
