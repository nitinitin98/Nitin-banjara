package basics1;

/* IMPORTANT: Multiple classes and nested static classes are supported */

/*
 * uncomment this if you want to read input.
//imports for BufferedReader
import java.io.BufferedReader;
import java.io.InputStreamReader;

//import for Scanner and other utility classes
import java.util.*;
*/
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;
import java.util.StringTokenizer;
// Warning: Printing unwanted or ill-formatted data to output will cause the test cases to fail

class Input_output {
	static class FastReader 
    { 
        BufferedReader br; 
        StringTokenizer st; 
  
        public FastReader() 
        { 
            br = new BufferedReader(new
                     InputStreamReader(System.in)); 
        } 
  
        String next() 
        { 
            while (st == null || !st.hasMoreElements()) 
            { 
                try
                { 
                    st = new StringTokenizer(br.readLine()); 
                } 
                catch (IOException  e) 
                { 
                    e.printStackTrace(); 
                } 
            } 
            return st.nextToken(); 
        } 
  
        int nextInt() 
        { 
            return Integer.parseInt(next()); 
        } 
  
        long nextLong() 
        { 
            return Long.parseLong(next()); 
        } 
  
        double nextDouble() 
        { 
            return Double.parseDouble(next()); 
        } 
  
        String nextLine() 
        { 
            String str = ""; 
            try
            { 
                str = br.readLine(); 
            } 
            catch (IOException e) 
            { 
                e.printStackTrace(); 
            } 
            return str; 
        } 
    } 
	
	
//	static int arr[] = new int[219997];
    public static void main(String args[] ) throws Exception {
//    	FastReader s=new FastReader(); 
//        long t= s.nextLong();
//    	int[] arr = {};
    	Scanner s = new Scanner(System.in);
        int t= s.nextInt();
        int[][] arr= new int[t][5];
        for(int i=0;i<t;i++){
            for(int j=0;j<4;j++){
                arr[i][j]= s.nextInt();
            }
            arr[i][4]=i+1;
        }
        Arrays.sort(arr,new Comparator<int[]>() {
		@Override
		public int compare(int[] a , int[] b) {
			return(a[0]-b[0])+(a[1]-b[1])+(a[2]-b[2])+(a[3]-b[3]);
		}
        });
        for(int[] a : arr) {
        	System.out.println(Arrays.toString(a));
        }
        
       
        
        

    }
}
