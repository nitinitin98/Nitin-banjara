package basics1;

import java.util.HashSet;
import java.util.Scanner;

public class pg {
	static int trail(int n){
        int two=0;
        int five=0;
        int count=0;
        while(n>0){
            if(n%10==0){
                int x=n;
                while(x%10==0){
                    count++;
                    x=x/10;
                    System.out.println(x);
                }
                continue;
            }
            if(n%2==0)
                two++;
            if(n%5==0)
                five++;
        n--;
        }
    return count;
    }
public static void main(String[] args) {
	System.out.println(trail(10));
}
}
