package medium;

public class MinimunCostTree {
	 public static boolean stoneGame(int[] piles) {
	        int i=0;
	        int j=piles.length-1;
	        int a=0,l=0;
	        while(i!=j && i<j){
	            if(piles[i]>piles[j]){
	                a+=piles[i];
	                System.out.println(a);
	                i++;
	            }else if(piles[i]==piles[j] && i+1!=j-1){
	                if(piles[i+1]>piles[j-1]) a+=piles[j--];
	                else a+=piles[i++];
	            }
	            else{
	                a+=piles[j];
	                System.out.println(a);
	                j--;
	            }
	            if(piles[i]>piles[j]){
	                l+=piles[i];
	                System.out.println(a);
	                i++;
	            }else if(piles[i]==piles[j] && i+1!=j-1 && i<j){
	                if(piles[i+1]>piles[j-1]) l+=piles[j--];
	                else l+=piles[i++];
	            }
	            
	            else{
	                l+=piles[j];
	                System.out.println(l);
	                j--;
	            }
	        }
	        System.out.println(a+" "+l);
	        return a>l;
	    }
	 public static void main(String[] args) {
		int[] a= {3,2,10,4};
		stoneGame(a);
	}
}
