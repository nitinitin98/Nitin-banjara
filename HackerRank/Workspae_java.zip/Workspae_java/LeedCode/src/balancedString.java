import java.util.Arrays;
import java.util.Comparator;
import java.util.PriorityQueue;

public class balancedString {
	 static public int lastStoneWeight(int[] stones) {
	        Arrays.sort(stones);
	        while(stones[stones.length-1]!=0 && stones[stones.length-2]!=0){
	        	System.out.println(Arrays.toString(stones));
	        for(int i=stones.length-1;i>0;i--){
	            if(stones[i-1]==0)
	                break;
	            stones[i]-=stones[i-1];
	            stones[i-1]=0;
	            i--;
	            }
	        Arrays.sort(stones);    
	        }
	        return stones[stones.length-1];
	    }
	
	public static void main(String[] args) {
		int[][] cost = {{10,20},{30,200}};
		int[][] a = Arrays.copyOf(cost, cost.length);
		System.out.println(a[0][0]);
		
		PriorityQueue<Integer> priorityQueue = new PriorityQueue<Integer>();
		
//		System.out.println(lastStoneWeight(stones));
	}
}
