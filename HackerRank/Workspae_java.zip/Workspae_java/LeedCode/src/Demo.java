import java.util.Comparator;
import java.util.HashMap;
import java.util.PriorityQueue;
import java.util.Scanner;
import java.util.Stack;

public class Demo {
 public static void main(String[] args) {
	 PriorityQueue<Integer> pq = new PriorityQueue<Integer>(new Comparator<Integer>() {});
	 Stack<Integer> l = new Stack<Integer>();
	 PriorityQueue<Integer> q = new PriorityQueue<Integer>();
	 HashMap<Integer,Integer> h = new HashMap<Integer, Integer>();
	 h.put(1, 1);
	 Scanner s = new Scanner(System.in);
	 s.skip("\r\n?");
	 String s1 = " a,b,c ";
	 Long l1 = 10l;
	 int x= l1.intValue();
	 System.out.println(s1.trim().replaceAll(",+", " "));
	 
	 
	 pq.add(1);pq.add(9);pq.add(7);pq.add(6);pq.add(5);pq.add(3);pq.add(2);
//	 System.out.println(pq.peek());
}
}
