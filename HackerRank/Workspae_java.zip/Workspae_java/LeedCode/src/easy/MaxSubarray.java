package easy;

import java.util.Arrays;

/*https://leetcode.com/problems/maximum-subarray/
 * Input: [-2,1,-3,4,-1,2,1,-5,4],
	Output: 6
Explanation: [4,-1,2,1] has the largest sum = 6.
 * */
public class MaxSubarray {
	
	public static int maxSubArraydp(int[] A) {
		int n = A.length;
        int[] dp = new int[n];//dp[i] means the maximum subarray ending with A[i];
        dp[0] = A[0];
        int max = dp[0];
        
        for(int i = 1; i < n; i++){
            dp[i] = A[i] + (dp[i - 1] > 0 ? dp[i - 1] : 0);
            max = Math.max(max, dp[i]);
        }
        System.out.println(Arrays.toString(dp));
        return max;  
    }
	public static int maxSubArray(int[] A) {
		int n = A.length;
//        int[] dp = new int[n];//dp[i] means the maximum subarray ending with A[i];
        int temp1 = A[0];
        int max = A[0];
        
        for(int i = 1; i < n; i++){
            int temp2 = A[i] + (temp1 > 0 ? temp1: 0);
            max = Math.max(max, temp2);
            temp1=temp2;
        }
//        System.out.println(Arrays.toString(dp));
        return max;  
    }
	
	public static void main(String[] args) {
		int[] A = {-2,1,-3,4,-1,2,1,-5,4};
		System.out.println(maxSubArray(A));
	}
}
