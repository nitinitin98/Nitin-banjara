package easy;



class Solution2 {
    public int maxProfit(int[] prices) {
        int min = Integer.MAX_VALUE;
        int prof=0;
        for(int i=0;i<prices.length;i++){
            if(prices[i]<min){
                min=prices[i];
            }else if(prices[i]-min>prof){
                prof=prices[i]-min;
            }
        }
        return prof;
            
    }
}
class Sol {
    public int maxProfit(int[] prices) {
        int prof=0;
        for(int i=0;i<prices.length-1;i++){
            int diff=0;
            for(int j=i+1;j<prices.length;j++){
                diff=diff>prices[j]-prices[i]?diff:prices[j]-prices[i];
            }
            prof=prof>diff?prof:diff;
        }
        return prof;
            
    }
}

public class BestTimetoBuyandSell {

}
