package queue_demos;
/*NavigableSet(I) And Map
 * -----------------------------------------
 * child interface of sorted set has methods for navigation 
 * methods-
 * (12346789)
 * lower(5);<4
 * floor(5);<=5
 * higher(5);>6
 * ceiling(5);>=6
 * 
 * pollFirst();remove 1st element
 * pollLast();
 * descendingSet(); reverse order
 * 
 * methods for map
 * ---------------------------
 * floorKey();
 * lowerKey();
 * ceilingKey();
 * higherKey();
 * pollFirstEntry();
 * pollLastEntry();
 * descendingMap();
 * 
 * */
public class NavigableSetAndMap {

}
