package queue_demos;

import java.util.PriorityQueue;

/*
 * Queue
 * ---------------------------------------
 * methods-
 * offer(object o);add object to queue
 * peek(); return head element if no then null
 * element();return head element if no then R.E no such element
 * poll();return head element after removing head i no then Null
 * remove();return head element after removing head i no then R.E
 * 
 * Priority-
 * ----------------------------
 * priority can be default or based
 * duplicates are not allowed
 * PriortyQueue p = new PriorityQueue();
 * PriortyQueue p = new PriorityQueue(cap);
 * PriortyQueue p = new PriorityQueue(cap,comparator);
 * PriortyQueue p = new PriorityQueue(Sorted s);
 * PriortyQueue p = new PriorityQueue(collection c);
 * -----------------------------
 * 
 * */
public class QueueDemo {
	public static void main(String[] args) {
		PriorityQueue p = new PriorityQueue();
		for(int i =0 ;i<10;i++ ) {p.offer(i);}
		System.out.println(p);
		System.out.println(p.poll());
		System.out.println(p.peek());
	}
}
