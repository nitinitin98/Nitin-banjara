package MapDemo;

import java.util.Collection;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/*
 * Map
 * -------------------------
 * map is not child interface of collection is imp based  hash table data struct. 
 * used for key value, pairs.
 * NOT good for RAndom Access but Good for Searching.
 * HashMap m = new HashMap();// Default cap-16, default fill ratio- 0.75
 * HashMap m = new HashMap(cap);// 
 * HashMap m = new HashMap(cap,fillratio);//
 * HashMap m = new HashMap(map m);//
 *   
 * Object put(obj key, obj value);// returns old value if replaced
 * void m.putAll(map m1);
 * object m.get(key);
 * object m.remove();
 * boolean m.containskey();
 * boolean m.containsValue();
 * boolean m.isEmpty();
 * int m.size();
 * void m.clear();
 * 
 * collection views of map
 * -----------------------------------
 * set m.keys();
 * collection m.values();
 * set entrySet();
 * 
 * Entry(I);
 * --------------------------
 * a map is a group of key value pairs and each pair is called an entry.
 * map is considered as a collection of entry objects.
 * without map their is no entry obj. hence entry interface is define inside map .
 * methods present in entry---
 * Object getkey();
 * Object getValue();
 * Object setValue();
 * above  methods are only for entry objects.
 * -----------------------------
 * HashMap vs HashTable
 * -----------------------------
 * not sysnc 		sync
 * not th safe		thread safe
 * high performance		low(relatively) 
 * null allowed(1)  R.E-Npe
 * 					legacy
 * 
 * map m1 =Collections.synchronizedMap(HashMap m);
 * 
 * LinkedHashMap
 * -------------------------------------------
 * insertion order is maintained used for cache based application. 
 * 
 * IdentityHashMAp
 * ----------------------------------------------
 * it will uses ==  operator instead of .equals. 
 * 
 * WeakHashMap
 * --------------------------
 * gcollector dominates.
 * */
public class MapDemo1 {
	public static void main(String[] args) {
		HashMap h = new HashMap();
//		h.put(5, 1);
//		h.put(2, 2);
//		h.put(3, 1);
//		h.put(4, 1);
		Integer i1 = new Integer(10);
		Integer i2 = new Integer(10);
		h.put(i1, "1st");
		h.put(i2, "2st");//i2 not inserted as a new value because jvm use .equals to compare
		IdentityHashMap hi = new IdentityHashMap();
		
		hi.put(i1, "1st");
		hi.put(i2, "2st");
		
		LinkedHashMap h1 = new LinkedHashMap();
		h1.put(5, 1);
		h1.put(2, 2);
		h1.put(3, 1);
		h1.put(4, 1);
//		System.out.println(h.put(1, 4));
		System.out.println(h1);
		
		Set s = h.keySet();
//		System.out.println(s);
		
		Collection c = h.values();
//		System.out.println(c);
		
		Set s1 = h.entrySet();
		Iterator i = s1.iterator();
		while(i.hasNext()) {
			Map.Entry m = (Map.Entry) i.next();
			//System.out.println(m.getKey()+"=="+m.getValue());
			if((int)m.getKey()==1) {
				m.setValue(100);
			}
		}
		//System.out.println(s1);
		
	
	}
}
