package MapDemo;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

/*SortedMap
 * ---------------------------
 * sorting is based on key using comparable or comparator.
 * methods();
 * Object firstKey();
 * Object LastKey();
 *
 * SortedMap headMap(107); keys less than 107
 * SortedMap tailMap(107); keys ge and eq to 107
 * SortedMap subMap(103,107); keys >=103 and <107
 * Comparator comparator();null for default sorting
 * 
 * TreeMap
 * -----------------------------
 * underlying data struct is Red-Black Tree
 * TreeMap t = new TreeMap();
 * TreeMap t = new TreeMap(comparator);
 * TreeMap t = new TreeMap(map m);
 * TreeMap t = new TreeMap(sortedMap m);
 * -------------------------------------
 * Hashtable
 * ----------------------------------------
 * based on hashcode  value is stored
 * 
 * 
 * Properties
 * ---------------------------------------------
 * Properties p = new Properties();//both key,values are of string typr
 * 
 * methods-
 * String getProperty(key);
 * String setProperty(key,value);//returns old value
 * Enumeration propertyNames();
 * 
 * load(InputStream s); loading properties from a property file to property object 
 * store(OutputStream o, String comments); and then again to store back to file
 * 
 * 
 * */
public class SortedMapDemo {
	public static void main(String[] args) throws Exception{
		Properties p = new Properties();
		FileInputStream i = new FileInputStream("A.properties");
		p.load(i);
		System.out.println(p);
		
		String s = p.getProperty("a");
		System.out.println(s);
		p.setProperty("a", "2556");
		FileOutputStream o = new FileOutputStream("A.properties");
		p.store(o, "Done");
		System.out.println(p);
	}
}
