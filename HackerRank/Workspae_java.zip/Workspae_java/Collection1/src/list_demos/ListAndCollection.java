package list_demos;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class ListAndCollection {
	
	public static void main(String[] args) {
//		Collection values = new ArrayList();
		Collection<Integer> values = new ArrayList<Integer>();
		values.add(1);
		values.add(2);
		values.add(3);
		values.add(4);
		values.remove(1);
//collection do not support insert 
//		Iterator i = values.iterator();
//		while(i.hasNext()) {
//			System.out.println(i.next());
//		}
		for (Integer i: values) {
			//System.out.println(i);
		}
		//int is supported beacuse of unboxing
		
		for (int i : values) {
			
		}
		System.out.println(values);
		
	}
}
