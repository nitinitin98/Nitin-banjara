package list_demos;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ListInterface {

	public static void main(String[] args) {
		List<Integer> values =new ArrayList<Integer>();
	
		values.add(1);
		values.add(2);
		values.add(3);
		values.add(4);
		values.add(1,99);
		System.out.println(values.toString());
		Collections.sort(values);
		System.out.println(values);
		values.forEach(System.out::println);
	}
}
