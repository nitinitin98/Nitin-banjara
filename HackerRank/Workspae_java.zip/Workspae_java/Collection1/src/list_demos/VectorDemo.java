package list_demos;

import java.util.ArrayList;
import java.util.Vector;

//dynamic array 
public class VectorDemo {
	public static void main(String[] args) {
		Vector<Integer> v = new Vector<Integer>();
		v.add(1);v.add(1);v.add(1);v.add(1);v.add(1);v.add(1);v.add(1);v.add(1);v.add(1);
		System.out.println(v.capacity());
//		v.add(1);v.add(1);v.add(1);v.add(1);v.add(1);
//		System.out.println(v.capacity());
		//vecotor dynamically inreases its size by 100% every time means *2
		v.remove(1);
		ArrayList<Integer> a = new ArrayList<Integer>();
		a.size();//0
		//array dynamically inreases its size by 50%
		// vector are thread safe array list are not 
		//vector is slow and array list is fast
		
		
		
	}
}
