
		/*
		Common methods
		boolean add(Object O);
		boolean addAll(Collection C);
		boolean remove(Object O);
		boolean removeAll(Collection C);
		void clear();//removes all
		boolean retainAll(Collection C);//except a present in c
		boolean contains((Object O);
		boolean containsAll(Collection C);
		boolean isEmpty();
		int size();
		Object[] toArray();
		Iterator iterator();
		
		*List
		*-------------------------------------
		*remove(A);value
		*remove(int index);
		*indexOf(A);
		*lastIndexOf(A);
		*get(index);
		*set(index,obj);
		*listIterator();
		*/
package ListDemo;

import java.util.ArrayList;
import java.util.LinkedList;

public class ListDemko {

	public static void main(String[] args) {

		ArrayList l = new ArrayList();//default capacity 10
		l.add(3);l.add(3);l.add(3);
		ArrayList l1 = new ArrayList(3);//with capacity
		ArrayList l2 = new ArrayList(l);//creates an array list obj of any collection
		//capacity increases by (current_capacity*3/2)+1
		LinkedList lil = new LinkedList<>(l);
		System.out.println(l2);
	}
}
