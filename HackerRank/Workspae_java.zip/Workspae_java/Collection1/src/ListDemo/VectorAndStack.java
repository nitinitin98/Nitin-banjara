package ListDemo;


/*Vector----------
 * --------------------------------
 * default capacity increases by *2
 * Vector v = new Vector(capacity);
 * Vector v = new Vector(collection);
 * Vector v = new Vector(capacity,incrementalCapacity);
 * Ex -Vector v = new Vector(500,10); initial =500,then =510,520,540;
 * v.addElement(obj);
 * v.removeElement(obj);
 * v.removeElementAt(index)
 * removeAllElement();
 * v.elementAt(index);
 * v.firstElement():
 * v.lastElement();
 * v.size(); elements present in vector
 * capacity();
 * Enumeration elements(); 
 * 
 * Stack------------------
 * Child class of vector 
 * if is design for last in first out
 * Stack s = new Stack();
 * methods-
 * -------------
 * object push(Object o);
 * object peak(); return top element without removal
 * object pop();
 * boolean empty();
 * int search(object); return offset(ex first,5th or any element  element from top of the stack ) if not return -1 
 * 
 * */
public class VectorAndStack {

}
