package ListDemo;

import java.util.ArrayList;
import java.util.LinkedList;
/*
 * LinkedList-----------
 * Usually used to impl. stack and queue for this we have.
 * Elements won't be stored in consecutive memory loactions.(retrieval is hard)
 * addFirst();
 * removeFirst();
 * addLast();
 * removeLast();
 * ----------------
 * 
 * */
public class LinkedListDemo {
public static void main(String[] args) {
	ArrayList l = new ArrayList();
	LinkedList lil = new LinkedList<>(l);
	
}
}
