package ListDemo;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Vector;

/*
 *Cursor----------
 *-----------------------------
 *get object one by ne i.e traverse
 *Enumeration
 *Iterator
 *ListIterator
 * 
 * */
public class CursorDemo {
	public static void main(String[] args) {
		Vector v = new Vector();
		for (int i=0;i<10;i++) {
			v.add(i);
		}
//		System.out.println(v);
		Enumeration e = v.elements();//
		/*Only two methods are their
		 * boolean hasMoreElements();
		 *Object e.nextElemts();
		 *only applicable for legacy classes
		 * */
		while(e.hasMoreElements()) {
			Integer i = (Integer)e.nextElement();
//			System.out.println(i%2==0?i:"");
		}
		/*using iterator() method from collection interface 
		 * boolean hasNext();
		 * Object next();
		 * Void remove();
		 *Limitations-
		 *-------------------
		 *we can only move in forward direction 
		 *addition is not possible
		 *modification is not possible
		 * 
		 * */
		Iterator i = v.iterator();
		
//		while(i.hasNext()) {
//			Integer a = (Integer) i.next();
//			if(a%2==0) {
//				i.remove();
//			}
//		}
		System.out.println(v);
		
		/*ListIterator (is child iterator of iterator)
		 * ----------------------------
		 *Bidirectional cursor 
		 * replacement and addition is possible 
		 * ListIterator itr = l.listIterator();//l is any list impl. class object  
		 * obj hasNext();
		 * obj next();
		 * int nextIndex();
		 * 
		 * obj hasPrevious();
		 * obj previous();
		 * int previousIndex();
		 * 
		 * void remove();
		 * void add(Object o);
		 * void set(Object o);
		 * 
		 * */
		ListIterator ltr = v.listIterator();//idem can be passed loop will start from that index
		/*
		 * ---------------------------------------
		 * Comparable(java.lang) and Comparator(java.util)
		 * ---------------------------------------
		 * comparator has two methods
		 * compare(); and equal();
		 * */
	}
}
