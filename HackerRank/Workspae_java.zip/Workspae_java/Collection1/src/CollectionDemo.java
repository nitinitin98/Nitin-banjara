import java.util.Arrays;

/*
 * 
 * */
public class CollectionDemo {
public static void main(String[] args) {
	int[] arr= {2 ,2 ,3 ,7};
	int s=0,e=arr.length-1;
    int count=0;
    int sum=0;
    Arrays.sort(arr);
    while(s!=e && s<e){
        if(arr[s]==arr[e]){
            e--;
        }else{
        	while(arr[e]!=arr[s]) {
	            if(arr[e]-arr[s]>=5){
	            	 sum+=((arr[e]-arr[s])/5)*5;
	            	 count=count+((arr[e]-arr[s])/5);
                     arr[s]+=((arr[e]-arr[s])/5)*5;
                     System.out.println(sum);
	            }else if(arr[e]-arr[s]>=2){
	                sum+=2;
	                arr[s]+=2;
	                count++; 
	            }else{
	                sum+=1;
	                arr[s]+=1;
	                count++; 
	            }
        	}
        	e--;
        	arr[e]+=sum;
        }
    }
    System.out.println(count);
}
}
