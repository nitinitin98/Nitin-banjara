package Recursion;

import java.util.Arrays;

public class Fibonaci {
	
	
	public static int fib(int n) {
		//base
		if(n==1 || n==2) {
			return 1;
		}
			if(n==0) return 0;
		return fib(n-2) + fib(n-1);
	}
	public static int finMemo(int n) {
		int[] lookup = new int[n];
		Arrays.fill(lookup,-1);
		lookup[0]=1;
		if(n>1)
		lookup[1]=1;
		return fibMemo(n, lookup);
	}
	public static int fibMemo(int n , int[] lookup) {
		if(n==0) return 0;
		if(lookup[n-1]==-1) {
		lookup[n-1]= fibMemo(n-2, lookup)+fibMemo(n-1, lookup);
		}
		else {
			return lookup[n-1];
		}
		return lookup[n-1];
	}
	public static int fibTab(int n) {
		if(n==0) return 0;
		int[] lookup = new int[n+1];
		lookup[0]=1;
		lookup[1]=1;
		for(int i = 0 ;i<n+1;i++) {
			if(lookup[i]==0) {
				lookup[i]=lookup[i-1]+lookup[i-2];
			}
		}
		return lookup[n];
	}
	
	
	public static void main(String[] args) {
		System.out.println(finMemo(26));
		System.out.println(fibTab(3));
	}
}
