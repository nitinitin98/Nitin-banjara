package Recursion;

public class FrogJump {

	public static int  jumpsRec(int n) {
		//base case
		if(n<0) return 0;
		if(n==0 || n==1) return 1;
		
		return jumpsRec(n-1)+jumpsRec(n-2); 
	}
	
	public static int jumpTab(int n) {
		int[] ways = new int[n+1];
		ways[0]=1;
		if(n>1)
		ways[1]=1;
		for (int i =2 ;i<n+1;i++) {
			
				ways[i]=ways[i-1]+ways[i-2];
			
		}
		return ways[n];
	}
	
	public static int jumpMemo(int n) {
		int[] ways = new int[n+1];
		ways[0]=1;
		ways[1]=1;
		return jumpMemo(n, ways);
	}
	
	public static int jumpMemo(int n,int[] ways) {
//		if(n<1) return 0;
		if(ways[n]==0) {
			ways[n]=jumpMemo(n-1, ways)+jumpMemo(n-2, ways);
		}
		
		return ways[n];
	}
	//for variable steps and x contains the steps it can take
	public static int jumpBottomup(int n,int[] x) {
		int[] ways = new int[n+1];
		ways[0]=1;
		for (int i =1 ;i<n+1;i++) {
			int sum=0;
			for(int j =0 ;j<=x.length;j++) { 
				if(i-j>=0) {
				sum+=ways[i-j];
				
				}
			}
			ways[i]=sum;
			
		}
		return ways[n];
	}
	//using two variables to save memory
	public static int jumpTwoVar(int n) {
//		int[] ways = new int[n+1];
//		ways[0]=1;
//		if(n>1)
//		ways[1]=1;
		int temp1=1;
		int temp2=1;
		int res=0;
		for (int i =2 ;i<n+1;i++) {
				res=temp1+temp2;
				temp1=temp2;
				temp2=res;
			
		}
		return res;
	}
	
	
	
	
	public static void main(String[] args) {
		System.out.println(jumpsRec(12));
		System.out.println(jumpTab(12));
		System.out.println(jumpMemo(2));
		int[] a = {1,2};
		System.out.println(jumpBottomup(12, a));
		System.out.println(jumpTwoVar(12));
	}
	
}
