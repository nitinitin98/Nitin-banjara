package greedy;
import java.io.*;
import java.util.*;
import java.math.*;
public class MinAbsDiff {
	static int minimumAbsoluteDifference(int[] arr) {
        int min =Integer.MAX_VALUE;
        Arrays.sort(arr);
        for (int i=0 ;i<arr.length-1; i++){
                min=Math.abs(arr[i]-arr[i+1])<min?Math.abs(arr[i]-arr[i+1]):min;
   
        }
        return min;
    }
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int n = Integer.parseInt(s.nextLine());
		String[] s1 = s.nextLine().split(" ");
		int[] arr= new int[s1.length];
		for(int x=0;x<n;x++) {
			arr[x]= Integer.parseInt(s1[x]);
		}
		int x1=minimumAbsoluteDifference(arr);
		System.out.println(x1);
	}
	
}
