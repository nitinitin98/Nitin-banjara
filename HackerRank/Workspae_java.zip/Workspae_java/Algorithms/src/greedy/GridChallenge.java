package greedy;
import java.io.*;
import java.util.*;
public class GridChallenge {
	static String gridChallenge(String[] grid) {
        String[][] s = new String[grid.length][];
        int x=0;
        for (String s1: grid){
            s[x]= s1.split("");
            Arrays.sort(s[x++]);
        }
        for(int i=0;i<s.length-1;i++){
           for(int j=0;j<s[i].length;j++){
                if(s[i][j].charAt(0)>s[i+1][j].charAt(0)){
                    return "NO";
                }

        }
        }
         return "YES" ;
    }
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int t = scanner.nextInt();
        scanner.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");

        for (int tItr = 0; tItr < t; tItr++) {
            int n = scanner.nextInt();
            scanner.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");

            String[] grid = new String[n];

            for (int i = 0; i < n; i++) {
                String gridItem = scanner.nextLine();
                grid[i] = gridItem;
            }

            String result = gridChallenge(grid);
            System.out.println(result);
		
	}
	}
}
