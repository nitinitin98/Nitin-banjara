package greedy;
import java.util.*;
public class LuckBalance {
	 static int luckBalance(int k, int[][] contests) {
	        int max=0;
	        int count=0;
	        Arrays.sort(contests,new Comparator<int[]>(){
	        	public int compare(int[] a, int[] b) {
	        		return b[0]-a[0];
	        	}
	        });
	      for (int [] i: contests){
	          if(i[1]==0){
	              max+=i[0];
	          }else if(count<k){
	              max+=i[0];
	              count++;
	          }else{
	              max-=i[0];
	          }
	      }  
	    return max;
	    }
	 public static void main(String[] args) {
		
	}
}
