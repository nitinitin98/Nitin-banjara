package greedy;
import java.io.*;
import java.util.*;

public class MarcCakewalk {
	static long marcsCakewalk(int[] calorie) {
        Arrays.sort(calorie);
        long sum=0;
        int p=calorie.length-1;
        for(int i: calorie){
            sum+=Math.pow(2,p--)*i;
        }
       
        return sum;
    }
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int x = scan.nextInt();
		int[] arr = new int[x];
		for(int i=0;i<x;i++) {
			arr[i]=scan.nextInt();
		}
		System.out.println(marcsCakewalk(arr));
	}
}
