package backtracking;

import java.util.Arrays;

public class Knighttour {
	static int N= 8;
	static boolean isValid(int x, int y,int[][] sol) {
		return (x>=0 && x<N) && (y>=0 && y<N)&&(sol[x][y]==-1);
	}
	static boolean Kt() {
		int[][] sol= new int[N][N];
		for (int x = 0; x < N; x++) 
            for (int y = 0; y < N; y++) 
                sol[x][y] = -1;
		int[] xa= {2, 1, -1, -2, -2, -1, 1, 2};
		int[] ya= {1, 2, 2, 1, -1, -2, -2, -1};
		sol[0][0]=0;
		if(sol(0, 0, 1, xa, ya, sol)) {
			for(int[] i: sol) {
				System.out.println(Arrays.toString(i));
			}
			return true;
		}
		else
			return false;
		
	}
	static boolean sol(int x, int y, int step, int[] xa,int[] ya,int[][] sol) {
		int next_x,next_y;
		
		if(step==N*N) {
			return true;
		}
 
		for(int i=0;i<xa.length;i++) {
			next_x=x+xa[i];
			next_y=y+ya[i];
			if(isValid(next_x, next_y, sol)) {
				sol[next_x][next_y]=step;
				if(sol(next_x, next_y, step+1, xa, ya, sol))
					return true;
				else {
					sol[next_x][next_y]=-1;
				}
			}
		}
		return false;
	}
	
	public static void main(String[] args) {
		Kt();
	}
}
