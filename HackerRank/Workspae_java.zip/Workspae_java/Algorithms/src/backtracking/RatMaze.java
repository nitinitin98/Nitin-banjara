package backtracking;

import java.util.Arrays;
//replace 3 with length 
public class RatMaze {
	
	static boolean check(int[][] maze,int x,int y) {
		if((x >= 0 && x < 4 && y >= 0 && y < 4 && maze[x][y] == 1)) {
			return true;
		}else {
			return false;
		}
	}
	
	static boolean solveMaze(int[][] maze,int[][] sol,int x, int y ) {
			if(x==3 && y==3) {
				sol[x][y]=1;
				return true;
			}
			if(check(maze, x, y)) {
				sol[x][y]=1;
				if(solveMaze(maze,sol, x+1, y))
					return true;
				if(solveMaze(maze,sol, x, y+1))
					return true;
				sol[x][y]=0;
			}
			return false;
		
		}
	
	static void solveMaze(int[][] maze) {
	int[][] sol= new int[maze.length][maze[0].length];	
	
	System.out.println(solveMaze(maze, sol,0, 0));
		for(int[] i:sol) {
			System.out.println(Arrays.toString(i));
		}
	}
	
	
	public static void main(String[] args) {
		RatMaze rat = new RatMaze(); 
        int maze[][] = { { 1,1, 1, 0 }, 
                         { 1, 1, 0, 1 }, 
                         { 0, 1, 1, 1}, 
                         { 1, 1, 0, 1 } }; 
  
        int N = maze.length; 
        rat.solveMaze(maze);
	}
}
