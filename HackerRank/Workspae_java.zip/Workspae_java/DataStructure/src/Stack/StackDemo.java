package Stack;

public class StackDemo {
	
	int stack[]= new int[5];
	int top=0;
	public void push(int data) {
		if(!isFull()) {
		stack[top]=data;
		top++;}
		else {
			System.out.println("Stack is full");
		}
	}
	
	public int pop() {
		if(!isEmpty()) {
			top--;
			int pop_element=stack[top];
			stack[top]=0;
			return pop_element;
		}
		System.out.println("Stack is empty");
		return 0;
		
	}
	public int peak() {
		return stack[top-1];
	}
	
	public int size() {
		return top;
	}
	public boolean isEmpty() {
		if(top==0) 
			return true;
		return false;
	}
	public boolean isFull() {
		if(top==5) 
			return true;
		return false;
	}
	
	public void show() {
		for (int n: stack) {
			System.out.print(n + " ");
		}
	}
	
	public static void main(String[] args) {
		StackDemo sd = new StackDemo();
		sd.push(1);
		sd.push(2);
		sd.push(3);
		sd.push(3);
		sd.push(3);
		sd.push(3);
		 
		System.out.println(sd.isFull());
		sd.show();
	}
}
