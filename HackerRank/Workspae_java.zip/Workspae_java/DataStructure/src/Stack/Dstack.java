package Stack;

public class Dstack {
	int capacity =2;
	int stack[]= new int[capacity];
	int top=0;
	public void push(int data) {
		if(isFull())
			expand();
		stack[top]=data;
		top++;
		
	}
	public void expand() {
		capacity*=2;
		int newStack[]= new int[capacity];
		System.arraycopy(stack, 0, newStack, 0, size());
		stack=newStack;
	}
	public int pop() {
		if(isEmpty()) {
			System.out.println("Stack is empty");
		}
		else{
			top--;
			int pop_element=stack[top];
			stack[top]=0;
			shrink();
			return pop_element;
		}
		return 0;
		
	}
	private void shrink() {
		int length = size();
		if(length<=stack.length/4) {
			capacity/=2;
			int newStack[]= new int[capacity];
			System.arraycopy(stack, 0, newStack, 0, size());
			stack=newStack;
		}
		
	}
	public int peak() {
		return stack[top-1];
	}
	
	public int size() {
		return top;
	}
	public boolean isEmpty() {
		if(top==0) 
			return true;
		return false;
	}
	public boolean isFull() {
		if(top==capacity) 
			return true;
		return false;
	}
	
	public void show() {
		for (int n: stack) {
			System.out.print(n + " ");
		}
	}
	public static void main(String[] args) {
		Dstack d = new Dstack();
		d.push(1);
		d.push(1);
		d.push(1);
		d.push(1);
		d.push(1);
		
		d.pop();d.pop();
		
		d.show();
	}		
}
