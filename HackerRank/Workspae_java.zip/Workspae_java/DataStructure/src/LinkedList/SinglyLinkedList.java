package LinkedList;

import java.util.Stack;

//using array

class LinkedList{
	Node head;
	
	public void insert(int data) {
		Node node = new Node();
		node.data=data;
		node.next=null;
		if(head==null) {
			head=node;
		}else {
			Node n = head;
			while(n.next!=null) {
				n=n.next;
			}
			n.next=node;
			
		}
		
	}
	public void insertAtStart(int data) {
		Node node = new Node();
		node.data=data;
		node.next=null;
		
		node.next=head;// assigning value of head reference to new head
		head = node;
	}
	
	public void insertAt(int index, int data) {
		Node node = new Node();
		node.data=data;
		node.next=null;
		if(index==0) {
			insertAtStart(data);
		}else {
		Node n =head;
		for (int i=0; i<index-1;i++) {
			n=n.next;
		}
		node.next=n.next;
		n.next=node;
		}
	}
	
	public void delete(int index) {
		if(index==0) {
			head = head.next;
		}else {
		Node n =head;
		Node n1 =null;
		for (int i=0; i<index-1;i++) {
			n=n.next;
			
		}
			n1 =n.next;
			n.next=n1.next;
			System.out.println(n1.data);
			n1=null;
		}
	}
	
	public void show(){
		
		Node node =head;
		while(node.next!=null) {
			System.out.print(node.data+" ");
			node= node.next;
		}
		System.out.print(node.data);
		System.out.println();
	}
	public void mid() {
		Node ptr1 = head;
		Node ptr2=head; 
		while(ptr2.next!=null && ptr2.next.next!=null) {
			ptr2=ptr2.next.next;
			ptr1=ptr1.next;
		}
		
		System.out.println(ptr1.data);
	}
//removes duplicates from a sorted list
	public void removeDuplicates() {
		Node n = head;
		while(n.next!=null) {
			if(n.data==n.next.data) {
				n.next=n.next.next;
				
			}else {
				n=n.next;
			}
			
		}
		
	}
/*Number is represented in linked list such that each digit corresponds to a node in linked list.
 *  Add 1 to it. For example 1999 is represented as (1-> 9-> 9 -> 9)
 *   and adding 1 to it should change it to (2->0->0->0)
 * */
	public void addOne() {
		Node n = head;
		Stack<Node> s= new Stack<Node>();
		while(n.next!=null) {
			s.push(n);
			n= n.next;
		}
		s.push(n);
		while(!s.isEmpty()) {
			Node n1 = s.pop();
			n1.data=n1.data+1;
			if(n1.data>9) {
				n1.data=0;
				if(n1==head) {
					Node node = new Node();
					node.data=1;
					node.next=n1;
					head= node;
					break;
				}
			}
			else break;
		}
	}
	public int addwithCarry(Node node) {
		if(node==null) return 1;
		int res=node.data+addwithCarry(node.next);
		node.data= res%10;
		return res/10;
	}
	public  void addOne1() 
    { 
  
        // Add 1 to linked list from end to beginning 
        int carry = addwithCarry(head); 
        if (carry > 0) 
        { 
            Node newNode = new Node(); 
            newNode.data=carry;
            newNode.next = head; 
            head= newNode;// New node becomes head now 
        } 
    }
	public int size() {
		return size(head);
	}
	public int size(Node head) {
		if(head.next==null) {
			return 1;
		}
		return 1+size(head.next);
	}
// reverse a linked list
	public void reverse() {
		Node prev= null;
		Node curr= head;
		Node next = null;
		while(curr!=null){
			next=curr.next;
			curr.next=prev;
			prev=curr;
			curr=next;
		}
		head=prev;
	}
	
}
public class SinglyLinkedList {
	public static void main(String[] args) {
		LinkedList list = new LinkedList();
		list.insert(9);
		list.insert(9);
		list.insert(9);
		list.insert(9);
//		list.insert(1);
//		list.insert(2);
//		list.insertAtStart(10);
//		list.insertAt(0,12);
//		list.delete(1);
//		list.removeDuplicates();
//		list.addOne1();
//		list.reverse();
		list.show();
//		list.mid();
		System.out.println(list.size());
	}
}


