package LinkedList;

import java.util.HashSet;

public class LinkedListLoopDetection {

	static Node head; // head of list   
    /* Linked list Node*/
    static class Node { 
        int data; 
        Node next; 
        Node(int d) 
        { 
            data = d; 
            next = null; 
        } 
    }
    static public void push(int new_data) 
    { 
        Node new_node = new Node(new_data); 
        new_node.next = head; 
        head = new_node;
    }
    //Using Hash table method
    public static boolean detect(Node h)
    {
    	HashSet<Node> s = new HashSet<Node>();
    	while(h!=null) {
    		if(s.contains(h)) return true;
    		s.add(h);
    		h=h.next;
    	}
    	return false;
    }
    //using two pointer
    public static boolean detect() {
    	Node slow_p = head, fast_p = head; 
        while (slow_p != null && fast_p != null && fast_p.next != null) { 
            slow_p = slow_p.next; 
            fast_p = fast_p.next.next; 
            if (slow_p == fast_p) { 
                System.out.println("Found loop"); 
                return true; 
            } 
        } 
        return false; 
    	
    	
    }
    
    
	public static void main(String[] args) {
		LinkedListLoopDetection llist = new LinkedListLoopDetection();
		llist.push(20); 
        llist.push(4); 
        llist.push(15); 
        llist.push(10);
//        llist.head.next.next.next.next = llist.head; 
        System.out.println(detect()); 
	}
}
