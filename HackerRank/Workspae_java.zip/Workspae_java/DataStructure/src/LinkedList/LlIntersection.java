package LinkedList;

public class LlIntersection {
	static Node head1, head2; 
	  
    static class Node { 
  
        int data; 
        Node next; 
  
        Node(int d) 
        { 
            data = d; 
            next = null; 
        } 
    }
    public int getCount(Node node) 
    { 
        Node current = node; 
        int count = 0; 
  
        while (current != null) { 
            count++; 
            current = current.next; 
        } 
  
        return count; 
    } 
    public int getNode() 
    { 
        int c1 = getCount(head1); 
        int c2 = getCount(head2); 
        int d; 
  
        if (c1 > c2) { 
            d = c1 - c2; 
            return getIntesectionNode(d, head1, head2); 
        } 
        else { 
            d = c2 - c1; 
            return getIntesectionNode(d, head2, head1); 
        } 
    }
    
    public int  getIntesectionNode(int d, Node node1, Node node2) 
    { 
    	Node c1 = node1;
    	Node c2 = node2;
    	for (int i=0;i<d;i++) {
    		if(c1.next==null) return -1; 
    		c1=c1.next;
    		
    	}
    	while(c1.next!=null && c2.next!=null) {
    		if(c1.data==c2.data) {
    			return c1.data;
    		}
    		else {
				c1=c1.next;
				c2=c2.next;
    		}
    	}
    	
    	
    	return -1; 
    	
    }
    public static void main(String[] args) { 
    	LlIntersection list = new LlIntersection(); 
  
        // creating first linked list 
        list.head1 = new Node(3); 
        list.head1.next = new Node(6); 
        list.head1.next.next = new Node(9); 
        list.head1.next.next.next = new Node(15); 
        list.head1.next.next.next.next = new Node(30); 
  
        // creating second linked list 
        list.head2 = new Node(10); 
        list.head2.next = new Node(15); 
        list.head2.next.next = new Node(30); 
  
        System.out.println("The node of intersection is " + list.getNode()); 
    } 
    
    
}
