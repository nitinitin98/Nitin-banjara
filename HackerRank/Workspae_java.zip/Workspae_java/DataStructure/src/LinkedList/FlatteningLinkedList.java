package LinkedList;

public class FlatteningLinkedList {
	Node head;
//	SinglyLinkedList l;
	class Node{
		int data;
		Node right;
		Node down;
	}
	public Node merge(Node a, Node b) {
		Node result=null;
		if(a==null) return b;
		if(b==null) return a;
		if(a.data<b.data) {
			result=a;
			result.down= merge(a.down, b);
		}
		else {
			result=b;
			result.down= merge(a, b.down);
		}
		
		
		
		return result;
	}
	
	public Node faltten(Node root) {
		if(root.right==null || root.down==null) {
			return null;
		}else {
			root.right=faltten(root.right);
			root=merge(root, root.right);
		}
		return root;
		
	}
	
}
