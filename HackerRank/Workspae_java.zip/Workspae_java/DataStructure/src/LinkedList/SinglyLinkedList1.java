package LinkedList;
//doubly linked List

class DoublyLinkedList{
	Node head;
	
	public void insert(int i) {
		Node node = new Node();
		node.data=i;
		node.next=null;
		node.prev=null;
		if(head==null) {
			head=node;
		}
		else if(head!=null) {
			Node n = new Node();
			n=head;
			while(n.next!=null) {
				n=n.next;
			}
			n.next=node;
			node.prev=n;
		}
	}
	public void insertAtStart(int i) {
		Node node = new Node();
		node.data=i;
		node.next=head;
		node.prev=null;
		
		head.prev=node;
		head= node;
		
	}
	public void insertAtIndex(int index,int i) {
		Node node = new Node();
		node.data=i;
		node.next=null;
		node.prev=null;
		if(index==0) {
			insertAtStart(i);
		}else {
			Node n =head;
			for(int x=0;x<index-1;x++) {
				n=n.next;
			}
			
			node.next=n.next;
			node.prev=n;
			Node temp =n.next;
			n.next=node;
			temp.prev=node;
			
		}
		
	}
	public void delete(int index) {
		if(index==0) {
			head = head.next;
			head.prev=null;
		}else {
		Node n =head;
		Node n1 =null;
		for (int i=0; i<index-1;i++) {
			n=n.next;
			
		}
			n1 =n.next;
			n.next=n1.next;
			if(n1.next!=null) {
			Node temp = n1.next;
			temp.prev=n;
			}
			System.out.println(n1.data);
			n1=null;
		}}
	public void show(){
		
		Node node =head;
		while(node.next!=null) {
			System.out.println(node.data);
			node= node.next;
		}
		System.out.println(node.data);
		
		}

}



public class SinglyLinkedList1 {
	public static void main(String[] args) {
		DoublyLinkedList d = new DoublyLinkedList();
		d.insert(1);
		d.insert(2);
		d.insert(3);
		d.insert(4);
		d.insertAtStart(5);
//		d.insertAtIndex(4, 11);
		d.delete(4);
		d.show();
	}
}
