package Queue;

public class Queue {
	int queue[] = new int[5];
	int size;
	int front;
	int rear;
	
	public void enqueue(int data) {
		queue[rear]=data;
		rear=(rear+1)%queue.length;
		size++;
	}
	public int dequeue() {
		int data = queue[front];
		queue[front]=0;
		front=(front+1)%queue.length;
		size--;
		return data;
	}
	public void show() {
		for (int i =0 ;i<size;i++) {
			System.out.print(queue[(i+front)%5]);
		}
	}
	public boolean isEmpty() {
		if(size==0)
			return true;
		return false;
	}
	public boolean isFull() {
		if(size==queue.length)
			return true;
		return false;
	}
	
	public static void main(String[] args) {
		Queue q = new Queue();
		q.enqueue(1);
		q.enqueue(2);
		q.enqueue(3);	q.enqueue(4); q.enqueue(5);
		q.dequeue();q.dequeue();q.dequeue();
		q.enqueue(6);	q.enqueue(7); q.enqueue(8);
		q.show();
//		System.out.println(q.isFull());
	}
}
