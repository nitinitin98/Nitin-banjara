package Btree;

public class TreearrayImp {
	int[] arr = new int[1000];
	int index=1;
	//Lchild = 2x
	//Rchild = 2x+1
	public void insert(int data) {
		if(index==arr.length)
			return;
		arr[index++]=data;
	}
	public void print() {
		for(int i=1; i<index;i++) {
			System.out.print(arr[i]+" ");
		}
	}
	public void inOrder(int i) {
		if(i>index)
			return;
		System.out.print(arr[i]);
		inOrder(i*2);
		inOrder(i*2+1);
	}
	public void preOrder(int i) {
		if(i>index)
			return;
		inOrder(i*2);
		System.out.print(arr[i]);
		inOrder(i*2+1);
		}
		
	public void postOrder(int i) {
		if(i>index)
			return;
		inOrder(i*2);
		inOrder(i*2+1);
		System.out.print(arr[i]);
	}
	public static void main(String[] args) {
		TreearrayImp t = new TreearrayImp();
		t.insert(1);t.insert(2);t.insert(3);t.insert(4);t.insert(5);t.insert(6);
		t.print();
		t.inOrder(1);
		t.postOrder(1);
		t.preOrder(1);
	}
}
