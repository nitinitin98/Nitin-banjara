package Btree;

import java.util.LinkedList;
import java.util.Queue;



public class Btree {
	Node root;
	
	public void insert(int data) {
		root=insert(root, data);
	}
	
	
	public Node insert(Node root,int data) {
		
		if (root==null)
		{
			Node node = new Node();
			node.data=data;
			root=node;
			return root;
		}
		else if(data<root.data){
			root.left=insert(root.left,data);
		}else
			root.right=insert(root.right,data);
		
		return root;
	}
	public boolean search(int data) {
		return search(root,data);
	}
	public boolean search(Node root,int data) {
		if(root==null) {
			return false;
		}else if(root.data==data) {
			return true;
		}else if(data<=root.data) {
			return search(root.left, data);
		}else
		return search(root.right, data);
		
	}
	
	public void minimum() {
		System.out.println(minimum(root));
	}
//	public int minimum(Node root) {
//		if(root.left==null) {
//			return root.data;
//		}
//		else {
//			return minimum(root.left);
//		}
//	}
	public Node minimum(Node root) {
		if(root.left==null) {
			return root;
		}
		else {
			return minimum(root.left);
		}
	}
	public void max() {
		System.out.println(max(root));
	}
	public int max(Node root) {
		if(root.right==null) {
			return root.data;
		}
		else {
			return max(root.right);
		}
	}
	public int height() {
		return height(root);
	}
	
	public int height(Node root) {
		if(root==null)
			return -1;
		else {
			return  Math.max(height(root.left), height(root.right))+1; 
		}
	}
	public void levelOrder() {
		levelOrder(root);
		System.out.println();
	}
	public void levelOrder(Node root) {
		if(root==null)
			return;
		Queue<Node> q = new LinkedList<Node>();
		q.add(root);
		while(!q.isEmpty()) {
			Node n = q.peek();
			System.out.print(n.data+",");
			if(n.left!=null)
				q.offer(n.left);
			if(n.right!=null)
				q.offer(n.right);
			q.poll();
		}
	}
	
	public void inOrder() {
		inOrder(root);
		System.out.println();
	}
	public void inOrder(Node root) {
		if(root!=null) {
			inOrder(root.right);
			System.out.print(root.data+",");
			inOrder(root.left);
			
			
		}
	}
	
	public void preOrder() {
		preOrder(root);
		System.out.println();
	}
	public void preOrder(Node root) {
		if(root!=null) {
			System.out.print(root.data+",");
			preOrder(root.left);
			
			preOrder(root.right);
		}
	}
	
	public void postOrder() {
		postOrder(root);
		System.out.println();
	}
	public void postOrder(Node root) {
		if(root!=null) {
			postOrder(root.left);
			postOrder(root.right);
			System.out.print(root.data+",");
		}
	}
	
//	public void isBinarySearchTree() {
//		System.out.println(isBinarySearchTree(root, Integer.MIN_VALUE, Integer.MAX_VALUE));
//	}
//	public boolean isBinarySearchTree(Node root,int min,int max) {
//		if(root==null) 
//			return true;
//		if(root.data>min && root.data<max &&
//			isBinarySearchTree(root.left, min,root.data) &&
//			isBinarySearchTree(root.right, root.data, max)) {
//			return true;
//		}
//		else {
//			return false;
//		}
//	}
	public void isBinarySearchTree() {
		System.out.println(isBinarySearchTree(root));	
		}
	public boolean isBinarySearchTree(Node root) {
		if(root==null) 	return true;
		if(isBinaryLeft(root.left, root.data) &&
			isBinaryRight(root.right, root.data) &&
			isBinarySearchTree(root.left) &&
			isBinarySearchTree(root.right)
			) {
			return true;
		}
		return false;
	}
	public boolean isBinaryLeft(Node root,int data) {
		if(root==null) 	return true;
		if(root.data<data &&
			isBinaryLeft(root.left, data) &&
			isBinaryLeft(root.right, data)) {
			return true;
		}
		else return false;
		
	}
	public boolean isBinaryRight(Node root, int data) {
		if(root == null) return true;
		if( root.data>data &&
			isBinaryRight(root.left, data) &&
			isBinaryRight(root.right, data)) return true;
		else return false;
	}
	
	
	public void delete(int data) {
		delete(root,data);
	}
	public Node delete(Node root,int data) {
		if(root==null)return null;
		else if(data<root.data) {
			root.left=delete(root.left, data);
		}else if(data>root.data){
			root.right= delete(root.right, data);
		}else {
			//leaf
			if(root.left==null && root.right==null) {
				root=null;
			}
			//one child
			else if(root.left==null) {
//				 Node n = root;
				root=root.right;	
			}
			else if(root.right==null) {
				root= root.left;
			}
			//2 child
			else {
				Node temp = minimum(root.right);
				root.data=temp.data;
				root.right=delete(root.right, temp.data);
				
			}
		}
		return root;
	}
	
	
	public static void main(String[] args) {
		Btree tree = new Btree();
		
			tree.insert(7); 
	        tree.insert(4); 
	        tree.insert(9); 
	        tree.insert(1); 
	        tree.insert(6); 
//	        tree.insert(60); 
//	        tree.insert(80);
//	        tree.insert(10);
//	       System.out.println( tree.search(500));
//		tree.minimum();
//		tree.max();
//		tree.inOrder();
//		System.out.println(tree.height());
	       tree.levelOrder();
	       tree.postOrder();
	       tree.preOrder();
	       tree.inOrder();
//	       tree.isBinarySearchTree();
//	       tree.delete(7);
//	       tree.inOrder();
	       
	
	}
}
