package Btree;

import java.util.LinkedList;
import java.util.Queue;

public class Tree {
	Node root;
	public void insert(int data) {
		if(root==null) {
			Node n = new Node();
			n.data=data;
			root= n;
		}else {
			Queue<Node> q = new LinkedList<Node>();
			q.offer(root);
			while(!q.isEmpty()) {
				Node temp=q.peek();
				if(temp.left==null) {
					Node n = new Node();
					n.data=data;
					temp.left=n;
					break;
				}else if(temp.right==null) {
					Node n = new Node();
					n.data=data;
					temp.right=n;
					break;
				}else {
					q.offer(temp.left);
					q.offer(temp.right);
				}
				q.poll();
			}
		}
			
	}
	public void print() {
		print(root);
	}
	public void print(Node root) {
		if(root==null)
			return;
		else {
			System.out.print(root.data+" ");
			print(root.left);
			print(root.right);
		}
	}
	public void delete(int data) {
		if(root==null)
			return;
		else {
			Queue<Node> q = new LinkedList<Node>();
			q.offer(root);
			Node t1 ;
			while(!q.isEmpty()) {
				Node temp=q.peek();
				if(temp.left!=null) {
					q.offer(temp.left);
				}
				if(temp.right!=null) {
					q.offer(temp.right);
				}
				t1=q.poll();
				root.data=t1.data;
				
			}
			
		}
	}
	public static void main(String[] args) {
		Tree t = new Tree();
		t.insert(2);
		t.insert(3);
		t.insert(4);
		t.insert(5);
		t.insert(6);
		t.insert(7);
		t.insert(8);
		t.print();
	}
}
