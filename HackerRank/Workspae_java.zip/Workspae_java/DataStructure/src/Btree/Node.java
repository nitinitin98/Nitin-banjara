package Btree;

public class Node {
	int data;
	Node left;
	Node right;
	
}
