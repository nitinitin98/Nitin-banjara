package Btree;

public class isBst {

}
