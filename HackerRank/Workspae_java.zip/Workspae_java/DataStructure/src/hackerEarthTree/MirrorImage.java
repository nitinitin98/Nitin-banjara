package hackerEarthTree;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class MirrorImage {
	static Node root;
	static class Node{
		Node left;
		Node right;
		int data;
	}
	static void insert(int p,int d,char c) {
		if(root==null) {
			Node node = new Node();
			node.data=1;
			root=node;
		}
		Queue<Node> q = new LinkedList<Node>();
		q.offer(root);
		Node n = new Node();
		n.data=d;
		while(!q.isEmpty()) {
			Node temp = q.peek();
			if(temp.data==p) {
				if(c=='R') {
					temp.right=n;
				}else {
					temp.left=n;
				}
			}
			if(temp.left!=null)
				q.offer(temp.left);
			if(temp.right!=null)
				q.offer(temp.right);
			q.poll();
		}
	}
	static int query(int data) {
		if(root.data==data)
			return data;
		else {
			Queue<Node> lq = new LinkedList<Node>();
			Queue<Node> rq = new LinkedList<Node>();
			Node n = new Node();
			n.data=-1;
			if(root.left!=null)
				lq.offer(root.left);
			else {
				return -1;
			}
			if(root.right!=null)
				rq.offer(root.right);
			else
				return -1;
			while(!lq.isEmpty() && !rq.isEmpty()) {
				Node l=lq.peek();
				Node r =rq.peek();
				if(l.data==data)
					return r.data;
				if(r.data==data)
					return l.data;
				if(l.left!=null && l.data!=-1)
					lq.offer(l.left);
				else {
					lq.offer(n);
				}
				if(l.right!=null && l.data!=-1)
					lq.offer(l.right);
				else {
					lq.offer(n);
				}
				if(r.right!=null && r.data!=-1)
					rq.offer(r.right);
				else {
					rq.offer(n);
				}
				if(r.left!=null && r.data!=-1)
					rq.offer(r.left);
				else {
					rq.offer(n);
				}
				lq.poll();
				rq.poll();
				
			}
			return -1;
		}
	}
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
	    
	    // Get L and R from the input
		int L = s.nextInt();
		int R = s.nextInt();
        for(int i=L;i<=R;i++)
            System.out.print(i+" ");
//		while(q-->0) {
//			int p= s.nextInt();
//			int d= s.nextInt();
//			char c =s.next
//		}
//		String s="R";
//		char c =s.charAt(0);
//		insert(1, 2, 'R');
//		insert(1, 3, 'L');
//		insert(2, 4, 'R');
//		insert(2, 5, 'L');
//		insert(3, 6, 'R');
//		insert(3, 7, 'L');
//		insert(7,10,'R');
//		System.out.println(c);
	}
}
