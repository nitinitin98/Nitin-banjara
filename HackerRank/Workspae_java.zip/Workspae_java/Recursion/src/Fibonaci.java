
public class Fibonaci {
	public static int fib(int a) {
		if(a==1 || a== 2) {
			return 1;
		}
		if(a==0) {
			return 0;
		}
		return fib(a-2)+fib(a-1);
	}
	public static void main(String[] args) {
		System.out.println(fib(40));
	}
}
