
public class FrogProblem {
	
	public static int solution(Integer i) {
		if(i==1 || i==0) {
			return 1;
		}
		if(i<1 ) {
			return 0;
		}
		
		return solution(i-1)+solution(i-2);
	}
	
	public static void main(String[] args) {
		System.out.println(solution(5));
	}
}
