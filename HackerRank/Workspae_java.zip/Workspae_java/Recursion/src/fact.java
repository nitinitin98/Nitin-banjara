
public class fact {
 
	public static int fact1(int i) {
		if(i==0) return 1;
		return i*fact1(i-1);
	}
	
	
	public static void main(String[] args) {
		System.out.println(fact1(3));
}
}
