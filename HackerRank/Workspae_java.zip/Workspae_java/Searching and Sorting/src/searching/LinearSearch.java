package searching;

public class LinearSearch {
	public static boolean search(int[] a,int b) {
		for(int x:a) {
			if(x==b)
				return true;
		}
		return false;
	}
public static void main(String[] args) {
	
}
}
