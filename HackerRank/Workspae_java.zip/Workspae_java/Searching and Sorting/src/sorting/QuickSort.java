package sorting;

public class QuickSort {

}
