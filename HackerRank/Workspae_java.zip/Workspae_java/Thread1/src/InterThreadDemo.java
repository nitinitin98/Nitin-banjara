class Q{
	int num;
	boolean valueSet=false;
	public synchronized void put(int n) {
		while(valueSet) {
			try{ wait();}catch(Exception e) {}// comes from object class
		}
		
		this.num=n;
		System.out.println("Put"+ num);
		valueSet=true;
		notify();
	}
	public synchronized  void get() {
		while(!valueSet) {
			try{ wait();}catch(Exception e) {}// comes from object class
		}
		System.out.println("Get"+ num);
		valueSet=false;
		notify();
	}
	
}
class Producer implements Runnable{
	Q q;

	public Producer(Q q) {
		this.q = q;
		Thread t1 = new Thread(this,"Producer");
		t1.start();
	}
	public void run() {
		int i=0;
		while(true) {
			q.put(i++);
			try { Thread.sleep(500);}catch(Exception e ) {}
		}
	}
}
class Consumer implements Runnable{
	Q q ;
	public Consumer(Q q) {
		this.q = q;
		Thread t2 = new Thread(this,"Consumer");
		t2.start();
	}
	public void run() {
		int i=0;
		while(true) {
			q.get();
			try { Thread.sleep(5000);}catch(Exception e ) {}
		}
	}
	
	
	
}



public class InterThreadDemo {
	static  public  void   main(String[] dsgnbnbsad ) {
		Q q = new Q();
		new Producer(q);
		new Consumer(q);
	}
}
