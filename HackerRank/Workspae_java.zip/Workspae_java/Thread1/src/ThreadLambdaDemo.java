
//join and alive
public class ThreadLambdaDemo {
	public static void main (String[] args) throws Exception{
		
		Thread th1 = new Thread(() ->{
			for (int i=1 ;i<5 ;i++) {
				System.out.println("HI");
				try{Thread.sleep(1000);}catch(Exception e ){}
				
			}	
			
	},"HI thread");
		Thread th2 = new Thread(()-> {
			for (int i=1 ;i<5 ;i++) {
				System.out.println("HELLO");
			}	

		
	});
		th1.start();
		try{Thread.sleep(10);}catch(Exception e ){}
		th2.start();
		
		th1.getPriority();
		th2.setPriority(10);
		th1.setPriority(Thread.MAX_PRIORITY);
		th2.setPriority(Thread.MAX_PRIORITY);
		
		
		
		th1.isAlive();
		
		th1.join();
		th2.join();
		
		th1.isAlive();
		System.out.println(th1.getName());
		th1.setName("thdfgh");
		System.out.println("bye");
	}
}


