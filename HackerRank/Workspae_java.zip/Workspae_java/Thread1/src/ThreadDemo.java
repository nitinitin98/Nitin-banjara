// thread using thread class

class A extends Thread{
	public void run() {
	for (int i=1 ;i<5 ;i++) {
		System.out.println("HI");
		try{Thread.sleep(500);}catch(Exception e ){}
		
	}	
	}
}
class B extends Thread {
	public void run() {
		for (int i=1 ;i<5 ;i++) {
			System.out.println("HELLO");
		}	

	}
}
public class ThreadDemo {
	public static void main(String[] args) {
		A ob1 = new A();
		B ob2 = new B();
		ob1.start();
		try{Thread.sleep(10);}catch(Exception e ){}
		ob2.start();
		
	}
}
