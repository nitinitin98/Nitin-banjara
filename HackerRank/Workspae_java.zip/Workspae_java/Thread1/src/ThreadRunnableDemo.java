// thread using thread class

class A1 implements Runnable{
	public void run() {
	for (int i=1 ;i<5 ;i++) {
		System.out.println("HI");
		try{Thread.sleep(500);}catch(Exception e ){}
		
	}	
	}
}
class B2 implements Runnable{
	public void run() {
		for (int i=1 ;i<5 ;i++) {
			System.out.println("HELLO");
		}	

	}
}
public class ThreadRunnableDemo {
	public static void main(String[] args) {
		A1 ob1 = new A1();
		B2 ob2 = new B2();
		
		Thread th1 = new Thread(ob1);
		Thread th2 = new Thread(ob2);
		th1.start();
		try{Thread.sleep(10);}catch(Exception e ){}
		th2.start();
		
	}
}


